import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  // I would normaly load files like is a better way but for this example this fits the brief 
  public faqs : any = [];
  title = 'ui-qa-component';
  constructor(private httpClient: HttpClient){}
  ngOnInit(){
    this.httpClient.get("assets/faqs.json").subscribe(data =>{
      console.log(data);
      this.faqs = data;
    })
  }
}
