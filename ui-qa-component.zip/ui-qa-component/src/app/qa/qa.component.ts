import { Component, Input } from '@angular/core';

@Component({
  selector: 'qa-accordion',
  templateUrl: './qa.component.html',
  styleUrls: ['./qa.component.sass']
})
export class QaComponent {
  @Input() faqs: {'id':string,'question':string,'anwser':string}[];
    
  constructor() { }

  clickEvent(faq){
    faq.status = !faq.status;    
  }
}
